### Resetting the High-Score-List:

Please duplicate the highscore_original.txt and rename it highscore.txt.

# Warning:

The file **highscore.txt in this directory should not be written by anyone** 
except by the program itself, or else the parsers may stop functioning due 
to a sensitive parsing algorithm. 

If you intent to **add questions**, please follow exactly the pattern in 
questions.txt, **pay special attention to whitespaces**. 